/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soothesphere;
import soothesphere.View.HomePage1;
import soothesphere.View.LogInPage;



/**
 *
 * @author User
 */
public class SootheSphere {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HomePage1 Hp = new HomePage1();
        Hp.setVisible(true);
//        LogInPage Lp = new LogInPage();
//        Lp.setVisible(true);
         


        
    }
   
}
